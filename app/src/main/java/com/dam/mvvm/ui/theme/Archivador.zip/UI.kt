package com.dam.mvvm.ui.theme

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

open class UI{

}
@Composable
fun InterfaceUsuario(miViewModel: MyViewModel){

    val TAG_LOG: String = "Mensaje UI"

    Column {
        Text(
            text = "numeros: ${miViewModel.getNumero()}",
            modifier = Modifier.padding(40.dp),
            color = Color.Black
        )



        OutlinedTextField(
            value = nameC.value,
            value = miViewModel.getNombre(),
            onValueChange = {
                nameC.value = it
                miViewModel._nameC.value = it
                            },
            label = { Text(
                text = "Introduzca un nombre",
                color= miColor ) },
            modifier=modifier.padding(0.dp,20.dp)
        )

        if (nameC.value.length>3){
            Text(text = "Nombre escrito: ${nameC.value}",
                if (miViewModel.getNombre().length>3){
                    Text(text = "Nombre escrito: ${miViewModel.getNombre()}",
                        fontSize = 25.sp,
                        modifier = Modifier.padding(vertical = 20.dp),
                        color= Color.Red
                }
        }
    }

}}
@Preview
@Composable
fun DefaultPreview(){

}






