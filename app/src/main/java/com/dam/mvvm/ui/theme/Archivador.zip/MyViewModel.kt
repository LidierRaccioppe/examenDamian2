package com.dam.mvvm.ui.theme

import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel

class MyViewModel() : ViewModel() {

    // para que sea mas facil la etiqueta del Log
    private val TAG_LOG: String = "Mensaje de ViewModel"

    // este v a a ser nuestra lista para la secuencia random
    // usamos mutable, ya que la queremos modificar
    var _numbers = mutableStateOf(0)
    var _nombre = mutableStateOf("Lidier Máximo Soberano de las Sillas con ")



    // inicializamos variables cunado instanciamos
    init {
        Log.d(TAG_LOG, "Inicialiazamos ViewModel")
    }

    /**
     * Creamos un entero aleatoria
     */
    fun CrearRandom(){
        _numbers.value = (0..10).random()
        Log.d(TAG_LOG,"creamos enteros random ${_numbers.value}")
    }

    /**
     * Devuelve el numero
     */
    fun getNumero():Int{
        return _numbers.value
    }

    /**
     * Devuelve el nombre
     */
    fun getNombre(): String{
        return _nombre.value
    }


























}